const express        = require('express');
const expressLayouts = require('express-ejs-layouts');
const sqlite3        = require('sqlite3').verbose();
const bodyParser     = require('body-parser');
const path           = require('path');
const session        = require('express-session');
const bcrypt         = require('bcryptjs');

const app  = express();
const PORT = 3000;

// ——— Database setup ———
const db = new sqlite3.Database(path.join(__dirname, 'db.sqlite'), err => {
  if (err) return console.error('DB error:', err.message);
  db.run(`CREATE TABLE IF NOT EXISTS authors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    lang TEXT NOT NULL
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS quotes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    author_id INTEGER,
    FOREIGN KEY(author_id) REFERENCES authors(id)
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    lang TEXT NOT NULL
  )`);
});

// ——— View engine and layouts ———
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(expressLayouts);

// ——— Middleware ———
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'kautkasupernoslepts',
  resave: false,
  saveUninitialized: false
}));

// ——— locals for templates ———
app.use((req, res, next) => {
  const lang = req.query.lang === 'en' ? 'en' : 'lv';
  res.locals.lang         = lang;
  res.locals.user         = req.session.user;
  res.locals.authorSearch = req.query.authorSearch ? req.query.authorSearch.trim() : '';
  next();
});

// ——— Authentication middleware ———
function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.redirect(`/login?lang=${res.locals.lang}`);
  }
  next();
}

// ——— Routes ———

// Home page with optional author filter
app.get('/', (req, res) => {
  const { lang, authorSearch } = res.locals;

  let sql = `SELECT q.text, a.name
               FROM quotes q
               JOIN authors a ON a.id = q.author_id
              WHERE a.lang = ?`;
  const params = [lang];

  if (authorSearch && authorSearch !== 'lv' && authorSearch !== 'en') {
    sql += ' AND a.name LIKE ?';
    params.push(`%${authorSearch}%`);
  }

  db.all(sql, params, (err, quotes) => {
    if (err) return res.status(500).send('DB error: ' + err.message);

    // Fetch distinct authors for dropdown
    db.all(
      `SELECT DISTINCT name FROM authors ORDER BY name`,
      [],
      (err2, rows) => {
        if (err2) return res.status(500).send('DB error: ' + err2.message);
        const authors = rows.map(r => r.name);
        res.render('index', { quotes, authors, authorSearch });
      }
    );
  });
});

// Registration
app.get('/register', (req, res) => {
  res.render('register', { error: null });
});
app.post('/register', async (req, res) => {
  const { username, pass1, pass2 } = req.body;
  const { lang } = res.locals;
  if (pass1 !== pass2) {
    return res.render('register', { error: 'Paroles nesakrīt' });
  }
  db.get('SELECT id FROM users WHERE username = ?', [username], async (err, row) => {
    if (err) return res.status(500).send('DB error: ' + err.message);
    if (row) return res.render('register', { error: 'Lietotājs jau eksistē' });
    const hash = await bcrypt.hash(pass1, 10);
    db.run(
      'INSERT INTO users(username,password,lang) VALUES(?,?,?)',
      [username, hash, lang],
      function (insertErr) {
        if (insertErr) return res.status(500).send('DB error: ' + insertErr.message);
        req.session.user = username;
        res.redirect(`/?lang=${lang}`);
      }
    );
  });
});

// Login
app.get('/login', (req, res) => {
  res.render('login', { error: null });
});
app.post('/login', (req, res) => {
  const { user, pass } = req.body;
  const { lang } = res.locals;
  db.get('SELECT password FROM users WHERE username = ?', [user], async (err, row) => {
    if (err) return res.status(500).send('DB error: ' + err.message);
    if (!row) return res.render('login', { error: 'Nepareizs lietotājs vai parole' });
    const match = await bcrypt.compare(pass, row.password);
    if (!match) return res.render('login', { error: 'Nepareizs lietotājs vai parole' });
    req.session.user = user;
    res.redirect(`/?lang=${lang}`);
  });
});

// Logout
app.post('/logout', (req, res) => {
  const { lang } = res.locals;
  req.session.destroy(() => res.redirect(`/login?lang=${lang}`));
});

// Add quote (protected)
app.post('/add', requireLogin, (req, res) => {
  const { text, author } = req.body;
  const { lang } = res.locals;
  db.get('SELECT id FROM authors WHERE name = ? AND lang = ?', [author, lang], (err, row) => {
    if (err) return res.status(500).send('DB error: ' + err.message);
    const saveQuote = id => db.run(
      'INSERT INTO quotes(text,author_id) VALUES(?,?)',
      [text, id],
      runErr => runErr
        ? res.status(500).send('DB error: ' + runErr.message)
        : res.redirect(`/?lang=${lang}`)
    );
    if (row) {
      saveQuote(row.id);
    } else {
      db.run(
        'INSERT INTO authors(name,lang) VALUES(?,?)',
        [author, lang],
        function (addErr) {
          if (addErr) return res.status(500).send('DB error: ' + addErr.message);
          saveQuote(this.lastID);
        }
      );
    }
  });
});

// Start server
app.listen(PORT, () => console.log(`Serveris http://localhost:${PORT}`));
